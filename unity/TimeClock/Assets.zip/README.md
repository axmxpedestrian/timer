# 🍅 Unity番茄钟 - Pomodoro Timer

一个简洁直观的番茄钟桌面应用，基于Unity开发。

---

## 📁 项目结构

```
PomodoroTimer/
├── Scripts/
│   ├── Core/                    # 核心逻辑
│   │   ├── PomodoroTimer.cs     # 计时器核心
│   │   ├── TaskManager.cs       # 任务管理
│   │   ├── DataManager.cs       # 数据持久化
│   │   └── StatisticsManager.cs # 统计管理
│   │
│   ├── Data/                    # 数据模型
│   │   ├── TaskData.cs          # 任务数据结构
│   │   ├── PomodoroRecord.cs    # 番茄钟记录
│   │   └── SaveData.cs          # 存档数据结构
│   │
│   ├── UI/                      # 界面控制
│   │   ├── MainUIController.cs  # 主界面
│   │   ├── TaskListUI.cs        # 任务列表
│   │   ├── TaskItemUI.cs        # 单个任务项
│   │   ├── StatisticsUI.cs      # 统计界面
│   │   ├── SettingsUI.cs        # 设置界面
│   │   └── BarChartUI.cs        # 柱状图组件
│   │
│   └── Utils/                   # 工具类
│       ├── ColorPalette.cs      # 颜色配置
│       └── AudioManager.cs      # 音效管理
│
├── Prefabs/                     # 预制体说明
├── Scenes/                      # 场景说明
└── README.md                    # 本文件
```

---

## 🎮 功能特性

### 核心计时
- ✅ 倒计时模式：专注(25分钟)、短休息(5分钟)、长休息(30分钟)
- ✅ 正计时模式：超10分钟计入专注，超120分钟自动中断
- ✅ 显示当前状态、轮次、计时类型

### 任务管理
- ✅ 创建/编辑/删除任务
- ✅ 任务颜色标记
- ✅ 任务与番茄钟绑定

### 统计报表
- ✅ 每日/每周柱状图
- ✅ 单任务/总任务统计
- ✅ 完成数量与时间追踪

### 其他功能
- ✅ 暂停/继续
- ✅ 数据自动存档
- ✅ 音效提醒
- ✅ 窗口置顶(可选)

---

## 🛠️ Unity设置步骤

### 1. 创建新项目
- Unity版本：2021.3 LTS 或更高
- 模板：2D (URP) 或 2D Core

### 2. 导入脚本
将 `Scripts` 文件夹拖入 Unity 的 `Assets` 目录

### 3. 场景搭建
详见下方 UI 层级结构

### 4. Player Settings
- Resolution: 1920 x 1080
- Resizable Window: ✓
- Run In Background: ✓

---

## 🎨 UI层级结构 (在Unity中创建)

```
Canvas (Screen Space - Overlay)
├── MainPanel
│   ├── Header
│   │   ├── TitleText
│   │   ├── TopMostToggle
│   │   └── SettingsButton
│   │
│   ├── TimerSection
│   │   ├── TimerBackground
│   │   ├── TimerText (00:00)
│   │   ├── StateText (专注中/休息中)
│   │   ├── RoundText (第1轮 / 共4轮)
│   │   ├── TimerTypeText (倒计时/正计时)
│   │   └── CurrentTaskText
│   │
│   ├── ControlButtons
│   │   ├── StartButton
│   │   ├── PauseButton
│   │   ├── StopButton
│   │   └── SkipButton
│   │
│   └── TaskSection
│       ├── TaskListHeader
│       │   ├── TaskListTitle
│       │   └── AddTaskButton
│       └── TaskScrollView
│           └── TaskListContent
│
├── SettingsPanel (默认隐藏)
│   ├── FocusDurationInput
│   ├── ShortBreakInput
│   ├── LongBreakInput
│   ├── RoundsInput
│   ├── SoundToggle
│   ├── CloseButton
│   └── SaveButton
│
├── StatisticsPanel (默认隐藏)
│   ├── Header
│   │   ├── TitleText
│   │   ├── DailyButton
│   │   ├── WeeklyButton
│   │   └── CloseButton
│   ├── ChartArea
│   │   └── BarChartContainer
│   ├── SummarySection
│   │   ├── TotalPomodorosText
│   │   ├── TotalTimeText
│   │   └── TaskDropdown
│   └── StatisticsButton (在主面板)
│
├── TaskEditPanel (默认隐藏)
│   ├── TaskNameInput
│   ├── ColorPicker
│   │   ├── ColorButton_Red
│   │   ├── ColorButton_Orange
│   │   ├── ColorButton_Yellow
│   │   ├── ColorButton_Green
│   │   ├── ColorButton_Blue
│   │   └── ColorButton_Purple
│   ├── SaveButton
│   ├── DeleteButton
│   └── CancelButton
│
└── TaskItemPrefab (预制体模板)
    ├── ColorBar
    ├── TaskNameText
    ├── PomodoroCountText
    ├── SelectButton
    └── EditButton
```

---

## 📝 使用说明

1. **启动应用** → 自动加载上次存档
2. **添加任务** → 点击"+"按钮，输入任务名，选择颜色
3. **选择任务** → 点击任务项绑定到当前番茄钟
4. **开始计时** → 点击"开始"按钮
5. **查看统计** → 点击统计按钮查看柱状图
6. **调整设置** → 点击设置按钮修改时长参数

---

## ⚙️ 默认参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| 专注时长 | 25分钟 | 可在设置中修改 |
| 短休息 | 5分钟 | 可在设置中修改 |
| 长休息 | 30分钟 | 每4个番茄钟后 |
| 正计时上限 | 120分钟 | 超时自动中断 |
| 正计时最小 | 10分钟 | 低于此不计入 |

---

## 🎵 音效资源

需要准备以下音效文件放入 `Resources/Audio/` 文件夹：
- `timer_complete.wav` - 计时结束提示音
- `button_click.wav` - 按钮点击音 (可选)

---

## 💾 存档位置

数据自动保存至：
```
Windows: %USERPROFILE%/AppData/LocalLow/[CompanyName]/[ProductName]/pomodoro_save.json
```
